<!-- Before opening an issue, please check a few things:

- Please check if a similar issue already exists.
- Are YouTube subscriptions not working? This may be the fault of the Piped instance. Please check if setting another instance (in the settings) fixes your issue.

-->

## Description

<!-- Insert description here -->

## Additional information

Installation method: <!-- Probably Flatpak -->

Version: <!-- From the about page -->

Additional information: <!-- Put any remaining information here -->
