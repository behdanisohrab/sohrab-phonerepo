DELETE FROM "providers" WHERE "name"="Steam";
