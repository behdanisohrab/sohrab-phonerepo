UPDATE "providers" SET website="https://www.nintendo.com/" WHERE name="Nintendo Account";
