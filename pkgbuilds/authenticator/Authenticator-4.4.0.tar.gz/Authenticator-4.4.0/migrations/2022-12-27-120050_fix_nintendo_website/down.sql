UPDATE "providers" SET website="https://accounts.nintendo.com/" WHERE name="Nintendo Account";
