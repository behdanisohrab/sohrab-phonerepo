mod camera_page;
mod password_page;
mod window;

pub use window::PreferencesWindow;
