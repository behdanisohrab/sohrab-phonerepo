import "@docsearch/css";
import { DocSearch } from "@docsearch/react";

function Search() {
  return (
    <DocSearch
      apiKey="b07d9adbf54ef4306a11233dd605d924"
      indexName="fvm"
      appId="NHQT1G41IK"
    />
  );
}

export default Search;
