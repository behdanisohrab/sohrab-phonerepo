Building
========
For build instructions see the README.md. For coding style,
conventions, etc. check phosh's [HACKING.md].

[HACKING.md](https://gitlab.gnome.org/World/Phosh/phosh/-/blob/main/HACKING.md)
