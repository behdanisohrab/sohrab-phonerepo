******************
Changes in Jansson
******************

.. include:: ../CHANGES
