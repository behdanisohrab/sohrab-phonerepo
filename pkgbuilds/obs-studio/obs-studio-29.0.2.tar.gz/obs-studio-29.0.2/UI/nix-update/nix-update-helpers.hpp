#pragma once

#include <cstdint>
#include <string>

std::string strprintf(const char *format, ...);
