#pragma once

void output_toggle();
OBSData load_settings();
void preview_output_toggle();
OBSData load_preview_settings();
