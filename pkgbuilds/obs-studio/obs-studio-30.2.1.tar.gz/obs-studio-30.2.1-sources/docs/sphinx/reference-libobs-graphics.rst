Graphics API Reference (libobs/graphics)
========================================

.. toctree::
   :maxdepth: 2

   reference-libobs-graphics-effects
   reference-libobs-graphics-vec2
   reference-libobs-graphics-vec3
   reference-libobs-graphics-vec4
   reference-libobs-graphics-quat
   reference-libobs-graphics-matrix4
   reference-libobs-graphics-math
   reference-libobs-graphics-image-file
   reference-libobs-graphics-axisang
   reference-libobs-graphics-graphics

